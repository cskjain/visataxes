
function calcLine3(){
	var w2box1 = document.getElementsByName("w2box1"); //get all the W2 box1 values
	var i = 0;
	var sumw2box1 = 0;
	for ( i = 0 ; i < w2box1.length ; i++ )
	{
		sumw2box1 = sumw2box1 + ( w2box1[i].value -1 + 1 ); // get the sum of all the W2 box1 values
	}
	
	var w2box8 = document.getElementsByName("w2box8"); //get all the W2 box8 values
	var j = 0;
	var sumw2box8 = 0;
	for ( j = 0 ; j < w2box8.length ; j++ )
	{
		sumw2box8 = sumw2box8 + ( w2box8[j].value -1 + 1 );// get the sum of all the W2 box8 values
	}
	var line6 = document.getElementById('line6').value;
	var line3 = Math.round ( sumw2box8 + sumw2box1 - line6);
	if (line3 < 0)
		line3 = 0;
	document.getElementById('line3').value = line3;
	calcLine7();
	
}


function calcLine5(){
	var box21042 = document.getElementsByName("1042sbox2"); //get all the 1024-s box2 values
	var i = 0;
	var sum1042sbox2 = 0;
	for ( i = 0 ; i < box21042.length ; i++ )
	{
		sum1042sbox2 = sum1042sbox2 + ( box21042[i].value -1 + 1 );// get the sum of all the 1024-s box2 values
	}
	
	var line5 = Math.round ( sum1042sbox2 );
	if (line5 < 0)
		line5 = 0;
	document.getElementById('line5').value = line5;
	calcLine7();
}

function calcLine4(){
	var box21099g = document.getElementsByName("1099gbox2"); //get all the 1024-s box2 values
	var i = 0;
	var sumbox21099g = 0;
	for ( i = 0 ; i < box21099g.length ; i++ )
	{
		sumbox21099g = sumbox21099g + ( box21099g[i].value -1 + 1 );// get the sum of all the 1024-s box2 values
	}
	
	var line4 = Math.round ( sumbox21099g );
	if (line4 < 0)
		line4 = 0;
	document.getElementById('line4').value = line4;
	calcLine7();
}

function calcLine7(){
	var line3 = document.getElementById("line3").value - 1 + 1 ;
	var line4 = document.getElementById("line4").value - 1 + 1 ;
	var line5 = document.getElementById("line5").value - 1 + 1 ;
	var line7 = Math.round ( line3 + line4 + line5 );
	if (line7 < 0)
		line7 = 0;
	document.getElementById("line7").value = line7;
	calcLine10();
	calcLine9();
}

function calcLine9_10(){
	calcLine9();
	calcLine10();
}

function calcLine9(){
	student_interest();
}

function calcLine10(){
	var line7 = document.getElementById("line7").value - 1 + 1 ;
	var line8 = document.getElementById("line8").value - 1 + 1 ;
	var line9 = document.getElementById("line9").value - 1 + 1 ;
	var line10 = Math.round ( line7 - ( line8 + line9 ) );
	if (line10 < 0)
		line10 = 0;
	document.getElementById("line10").value = line10;
	calcLine11();
	calcLine12();
}

function calcLine11(){
	calculate_tax();
	calcLine12();
}

function calcLine12(){
	var line10 = document.getElementById("line10").value - 1 + 1 ;
	var line11 = document.getElementById("line11").value - 1 + 1 ;
	var line12 = Math.round ( line10 - line11 );
	if (line12 < 0)
		line12 = 0;
	document.getElementById("line12").value = line12;
	calcLine14();
}

function calcLine14(){
	var line12 = document.getElementById("line12").value - 1 + 1 ;
	var line13 = document.getElementById("line13").value - 1 + 1 ;
	var line14 = Math.round ( line12 - line13 );
	if (line14 < 0)
		line14 = 0;
	document.getElementById("line14").value = line14;
	calcLine15();
}

function calcLine15(){
	calculateTax();
	calcLine17();
}

function calcLine16()
{
	var form4137b = ( document.getElementById('form4137b').value -1 + 1 );
	var form8919 = ( document.getElementById('form8919').value - 1 + 1 );
	var line16 = Math.round ( form4137b + form8919 ) ;
	if (line16 < 0)
		line16 = 0;
	document.getElementById('line16').value = line16;
	calcLine17();
}


function calcLine17(){
	var line15 = document.getElementById("line15").value - 1 + 1 ;
	var line16 = document.getElementById("line16").value - 1 + 1 ;
	var line17 = Math.round ( line15 + line16 );
	if (line17 < 0)
		line17 = 0;
	document.getElementById("line17").value = line17;
	calcLine22();
	calcLine25();
}

function calcLine19(){
	var line19 = document.getElementById("line19_value").value - 1 + 1 ;
	line19 = Math.round ( line19 );
	if (line19 < 0)
		line19 = 0;
	document.getElementById("line19").value = line19;
	calcLine21();
}



function calcLine20(){
	var line20 = document.getElementById("line20_value").value - 1 + 1 ;
	line20 = Math.round ( line20 );
	if (line20 < 0)
		line20 = 0;
	document.getElementById("line20").value = line20;
	calcLine21();
}


function calcLine21(){
	var line18 = document.getElementById("line18").value - 1 + 1 ;
	var line19 = document.getElementById("line19").value - 1 + 1 ;
	var line20 = document.getElementById("line20").value - 1 + 1 ;
	var line21 = Math.round ( line18 + line19 + line20 );
	if (line21 < 0)
		line21 = 0;
	document.getElementById("line21").value = line21;
	calcLine22();
	calcLine25();
}

function calcLine22(){
	var line21 = document.getElementById("line21").value - 1 + 1 ;
	var line17 = document.getElementById("line17").value - 1 + 1 ;
	var line22 = Math.round ( line21 - line17 );
	if ( line22 < 0 )
		line22 = 0 ;
	document.getElementById("line22").value = line22;
}

function calcLine25(){
	var line21 = document.getElementById("line21").value - 1 + 1 ;
	var line17 = document.getElementById("line17").value - 1 + 1 ;
	var line25 = Math.round ( line17 - line21 );
	if ( line25 < 0 )
		line25 = 0 ;
	document.getElementById("line25").value = line25;
}


function calcLine6_11(){
	tax_treaty();
	calcLine11();
}


function calcLine18(){
	var w2box2 = document.getElementsByName("w2box2");
	var i = 0;
	var sumw2box2 = 0;
	for ( i = 0 ; i < w2box2.length ; i++ )
	{
		sumw2box2 = sumw2box2 + ( w2box2[i].value -1 + 1 );
	}
	
	
	var box71042 = document.getElementsByName("1042sbox7");
	var j = 0;
	var sum1042sbox7 = 0;
	for ( j = 0 ; j < box71042.length ; j++ )
	{
		sum1042sbox7 = sum1042sbox7 + ( box71042[j].value -1 + 1 );
	}

	
	var box41099g = document.getElementsByName("1099gbox4");
	var k = 0;
	var sum1099gbox4 = 0;
	for ( k = 0 ; k < box41099g.length ; k++ )
	{
		sum1099gbox4 = sum1099gbox4 + ( box41099g[k].value -1 + 1 );
	}
	
	var line18 = Math.round ( sumw2box2 + sum1042sbox7 + sum1099gbox4 );
	if (line18 < 0)
		line18 = 0;
	document.getElementById('line18').value = line18;
	calcLine21();
	
}


function calcstate_local_taxes()
{
	var w2box17 = document.getElementsByName("w2box17");
	var i = 0;
	var sumw2box17 = 0;
	for ( i = 0 ; i < w2box17.length ; i++ )
	{
		sumw2box17 = sumw2box17 + ( w2box17[i].value -1 + 1 );
	}
	
	var w2box19 = document.getElementsByName("w2box19");
	var j = 0;
	var sumw2box19 = 0;
	for ( j = 0 ; j < w2box19.length ; j++ )
	{
		sumw2box19 = sumw2box19 + ( w2box19[j].value -1 + 1 );
	}
	
	var state_local_taxes = sumw2box17 + sumw2box19 ;
	if (state_local_taxes < 0)
		state_local_taxes = 0;
	document.getElementById('state_local_taxes').value = state_local_taxes;
	calcLine11();
}

function calcLine_1_2_9_11_13_15()
{
	document.getElementById('filingstatus_value').value = document.getElementById('filingstatus').value;
	calcLine9();
	calcLine11();
	calcLine15();
	
}